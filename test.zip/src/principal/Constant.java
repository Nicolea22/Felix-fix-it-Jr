package principal;

public class Constant {

	public final static int WIDTH = 800;
	public final static int HEIGHT = 600;
	public final static int STATES = 6;
	public final static int SECTORS = 4;
	
	public final static float GRAVITY = 5.5f;
	
}
