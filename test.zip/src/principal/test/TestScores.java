package principal.test;

import principal.Score;

public class TestScores {

}
