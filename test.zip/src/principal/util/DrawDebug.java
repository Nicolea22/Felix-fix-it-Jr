package principal.util;

// Esta clase dibuja los datos para debugear como los rectangulitos limites de colision
// para poder ver si la colision que se hace es correcta.

public class DrawDebug {

}
