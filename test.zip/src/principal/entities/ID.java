package principal.entities;

public enum ID {

	Felix(),
	Ralph(), 
	Bird(), 
	Brick(),
	Molding(),
	Building(),
	DoubleDoor(),
	TwoPanels(),
	Window(),
	Cake();
}
