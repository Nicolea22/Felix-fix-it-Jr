package principal.physics;

public class Displacement {

	private float dx;
	private float dy;
	
	public Displacement(){
		dx = 0;
		dy = 0;
	}

	// getters y setters
	public float getDx() {
		return dx;
	}

	public void setDx(float dx) {
		this.dx = dx;
	}

	public float getDy() {
		return dy;
	}

	public void setDy(float dy) {
		this.dy = dy;
	}
	
	
	
	
}
